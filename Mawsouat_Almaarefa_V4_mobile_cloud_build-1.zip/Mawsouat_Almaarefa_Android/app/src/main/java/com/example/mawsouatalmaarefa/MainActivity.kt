package com.example.mawsouatalmaarefa

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.android.gms.ads.MobileAds

private data class Fact(
    val id: Int, val categoryAr: String, val categoryEn: String,
    val titleAr: String, val titleEn: String, val bodyAr: String, val bodyEn: String
)

private data class QuizQuestion(val id: Int, val questionAr: String, val questionEn: String, val optionsAr: List<String>, val optionsEn: List<String>, val answer: Int, val explanationAr: String, val explanationEn: String)

private val quizQuestions = listOf(
    QuizQuestion(1, "ما أكبر كواكب المجموعة الشمسية؟", "Which is the largest planet in our solar system?", listOf("الأرض", "المشتري", "المريخ", "الزهرة"), listOf("Earth", "Jupiter", "Mars", "Venus"), 1, "المشتري هو أكبر كواكب المجموعة الشمسية.", "Jupiter is the largest planet in our solar system."),
    QuizQuestion(2, "ما أكبر محيط على سطح الأرض؟", "What is the largest ocean on Earth?", listOf("الأطلسي", "الهندي", "الهادئ", "المتجمد الشمالي"), listOf("Atlantic", "Indian", "Pacific", "Arctic"), 2, "المحيط الهادئ هو الأكبر مساحةً.", "The Pacific Ocean is the largest by area."),
    QuizQuestion(3, "كم قلباً يمتلك الأخطبوط؟", "How many hearts does an octopus have?", listOf("قلب واحد", "قلبان", "ثلاثة قلوب", "أربعة قلوب"), listOf("One", "Two", "Three", "Four"), 2, "يمتلك الأخطبوط ثلاثة قلوب.", "An octopus has three hearts."),
    QuizQuestion(4, "ما الغاز الذي تمتصه النباتات من الهواء؟", "Which gas do plants absorb from the air?", listOf("الأكسجين", "ثاني أكسيد الكربون", "النيتروجين", "الهيدروجين"), listOf("Oxygen", "Carbon dioxide", "Nitrogen", "Hydrogen"), 1, "تمتص النباتات ثاني أكسيد الكربون خلال البناء الضوئي.", "Plants absorb carbon dioxide during photosynthesis."),
    QuizQuestion(5, "كم دقيقة تقريباً يستغرق ضوء الشمس للوصول إلى الأرض؟", "About how many minutes does sunlight take to reach Earth?", listOf("دقيقة", "8 دقائق", "30 دقيقة", "ساعة"), listOf("1 minute", "8 minutes", "30 minutes", "1 hour"), 1, "يستغرق الضوء نحو 8 دقائق و20 ثانية.", "Sunlight takes about 8 minutes and 20 seconds."),
    QuizQuestion(6, "في أي قارة تقع جبال الأنديز؟", "On which continent are the Andes?", listOf("آسيا", "أفريقيا", "أمريكا الجنوبية", "أوروبا"), listOf("Asia", "Africa", "South America", "Europe"), 2, "تمتد جبال الأنديز على طول غرب أمريكا الجنوبية.", "The Andes run along the western side of South America.")
)

private val facts = listOf(
    Fact(1,"الفضاء والفلك","Space","المشتري أكبر الكواكب","Jupiter is the largest planet","المشتري هو أكبر كواكب المجموعة الشمسية، وله عاصفة ضخمة تُعرف بالبقعة الحمراء العظيمة.","Jupiter is the largest planet in our solar system and has a giant storm known as the Great Red Spot."),
    Fact(2,"الجغرافيا","Geography","المحيط الهادئ","The Pacific Ocean","المحيط الهادئ هو أكبر محيطات الأرض.","The Pacific Ocean is Earth's largest ocean."),
    Fact(3,"التاريخ","History","أهرامات الجيزة","The Giza Pyramids","تقع أهرامات الجيزة في مصر، وهي من أشهر آثار العالم القديم.","The Giza pyramids are in Egypt and are among the best-known monuments of the ancient world."),
    Fact(4,"الحيوانات","Animals","ثلاثة قلوب للأخطبوط","An octopus has three hearts","يمتلك الأخطبوط ثلاثة قلوب، ويساعده دمه الغني بالنحاس على نقل الأكسجين.","An octopus has three hearts, and its copper-rich blood helps transport oxygen."),
    Fact(5,"العلوم","Science","سرعة الضوء","The speed of light","تبلغ سرعة الضوء في الفراغ نحو 299,792 كيلومتراً في الثانية.","Light travels through a vacuum at about 299,792 kilometres per second."),
    Fact(6,"الفضاء والفلك","Space","الوصول إلى ضوء الشمس","Sunlight travel time","يستغرق ضوء الشمس نحو 8 دقائق و20 ثانية ليصل إلى الأرض.","Sunlight takes about 8 minutes and 20 seconds to reach Earth."),
    Fact(7,"الطبيعة","Nature","أطول سلسلة جبلية","The longest mountain range","سلسلة جبال الأنديز هي أطول سلسلة جبلية قارية فوق سطح الأرض.","The Andes are the longest continental mountain range above sea level."),
    Fact(8,"التكنولوجيا","Technology","أول حاسوب قابل للبرمجة","Early programmable computers","ظهرت الحواسيب الإلكترونية القابلة للبرمجة في منتصف القرن العشرين.","Electronic programmable computers emerged in the mid-20th century."),
    Fact(9,"العلوم","Science","الماء النقي","Pure water","يتجمد الماء النقي عند صفر درجة مئوية تقريباً عند الضغط الجوي المعتاد.","Pure water freezes at about 0°C at standard atmospheric pressure."),
    Fact(10,"العلوم","Science","رمز الذهب","Gold symbol","يرمز للذهب كيميائياً بالرمز Au.","The chemical symbol for gold is Au."),
    Fact(11,"العلوم","Science","عدد عظام الإنسان","Human bones","يولد الطفل بعظام أكثر من البالغ، ويلتحم بعضها أثناء النمو.","Babies are born with more bones than adults; some fuse as they grow."),
    Fact(12,"العلوم","Science","درجة غليان الماء","Water boiling point","يغلي الماء عند 100 درجة مئوية تقريباً عند مستوى سطح البحر.","Water boils at about 100°C at sea level."),
    Fact(13,"الفضاء والفلك","Space","الكوكب الأحمر","The Red Planet","يُعرف المريخ بالكوكب الأحمر بسبب أكاسيد الحديد في تربته.","Mars is called the Red Planet because of iron oxides in its soil."),
    Fact(14,"الفضاء والفلك","Space","أقرب نجم للأرض","Nearest star","الشمس هي أقرب نجم إلى الأرض.","The Sun is the closest star to Earth."),
    Fact(15,"الفضاء والفلك","Space","حلقات زحل","Saturn's rings","يشتهر زحل بنظام حلقاته الواسع المكوّن أساساً من جليد وصخور.","Saturn is famous for its extensive rings, made mostly of ice and rocky particles."),
    Fact(16,"الجغرافيا","Geography","أعلى جبل","Highest mountain","قمة إيفرست هي أعلى قمة جبلية فوق مستوى سطح البحر.","Mount Everest is the highest mountain peak above sea level."),
    Fact(17,"الجغرافيا","Geography","أكبر قارة","Largest continent","آسيا هي أكبر قارات العالم مساحةً وسكاناً.","Asia is the world's largest continent by area and population."),
    Fact(18,"الجغرافيا","Geography","أكبر صحراء حارة","Largest hot desert","الصحراء الكبرى هي أكبر صحراء حارة في العالم.","The Sahara is the world's largest hot desert."),
    Fact(19,"الجغرافيا","Geography","نهر النيل","The Nile","يمر نهر النيل عبر عدة دول أفريقية ويصب في البحر المتوسط.","The Nile flows through several African countries and empties into the Mediterranean Sea."),
    Fact(20,"الحيوانات","Animals","أكبر حيوان","Largest animal","الحوت الأزرق أكبر حيوان معروف عاش على الأرض.","The blue whale is the largest known animal to have lived on Earth."),
    Fact(21,"الحيوانات","Animals","سرعة الفهد","Cheetah speed","الفهد الصياد من أسرع الحيوانات البرية في العدو لمسافات قصيرة.","The cheetah is among the fastest land animals over short distances."),
    Fact(22,"الحيوانات","Animals","النحل والتواصل","Bee communication","تستخدم بعض أنواع النحل رقصة الاهتزاز لإرشاد أفراد الخلية إلى مصادر الغذاء.","Some bees use a waggle dance to guide nestmates to food sources."),
    Fact(23,"الحيوانات","Animals","البطريق","Penguins","معظم أنواع البطاريق تعيش في نصف الكرة الجنوبي.","Most penguin species live in the Southern Hemisphere."),
    Fact(24,"الطبيعة","Nature","ألوان قوس قزح","Rainbow colors","يظهر قوس قزح عندما ينكسر ضوء الشمس ويتشتت داخل قطرات الماء.","A rainbow forms when sunlight is refracted and dispersed in water droplets."),
    Fact(25,"الطبيعة","Nature","أطول شجرة","Tallest tree","تُعد أشجار الساحل الأحمر من أطول الأشجار المعروفة في العالم.","Coast redwoods include some of the tallest known trees in the world."),
    Fact(26,"الطبيعة","Nature","البناء الضوئي","Photosynthesis","تستخدم النباتات ضوء الشمس لتحويل الماء وثاني أكسيد الكربون إلى سكريات.","Plants use sunlight to turn water and carbon dioxide into sugars."),
    Fact(27,"التاريخ","History","اختراع الطباعة","Printing press","أسهمت مطبعة يوهانس غوتنبرغ في انتشار الطباعة بالحروف المتحركة في أوروبا.","Johannes Gutenberg's press helped spread movable-type printing in Europe."),
    Fact(28,"التاريخ","History","مكتبة الإسكندرية القديمة","Ancient Library of Alexandria","كانت مكتبة الإسكندرية القديمة من أشهر مراكز العلم والمعرفة في العالم القديم.","The ancient Library of Alexandria was one of the best-known centers of learning."),
    Fact(29,"التاريخ","History","سور الصين العظيم","Great Wall of China","يتكون سور الصين العظيم من أجزاء بُنيت في فترات تاريخية مختلفة.","The Great Wall of China consists of sections built in different historical periods."),
    Fact(30,"التكنولوجيا","Technology","لغة الإنترنت","Internet protocol","تساعد بروتوكولات TCP/IP الأجهزة المختلفة على التواصل عبر الإنترنت.","TCP/IP protocols allow different devices to communicate over the internet."),
    Fact(31,"التكنولوجيا","Technology","الرمز QR","QR code","يمكن تخزين بيانات مثل الروابط والنصوص داخل رمز الاستجابة السريعة.","A QR code can store data such as links and text."),
    Fact(32,"التكنولوجيا","Technology","الطاقة الشمسية","Solar energy","تحول الألواح الكهروضوئية ضوء الشمس مباشرة إلى طاقة كهربائية.","Photovoltaic panels convert sunlight directly into electrical energy."),
    Fact(33,"الصحة","Health","النوم","Sleep","يساعد النوم الكافي على دعم الذاكرة والانتباه والصحة العامة.","Adequate sleep supports memory, attention, and overall health."),
    Fact(34,"الصحة","Health","الماء والجسم","Water and the body","يساعد الماء الجسم على تنظيم حرارته ونقل المواد الغذائية.","Water helps the body regulate temperature and transport nutrients."),
    Fact(35,"الرياضة","Sports","عدد لاعبي كرة القدم","Football players","يتكون كل فريق كرة قدم من 11 لاعباً داخل الملعب أثناء اللعب.","A football team has 11 players on the field during play."),
    Fact(36,"الرياضة","Sports","الماراثون","Marathon","المسافة الرسمية لسباق الماراثون هي 42.195 كيلومتراً.","The official marathon distance is 42.195 kilometres."),
    Fact(37,"الفنون","Arts","الألوان الأساسية للضوء","Primary light colors","الألوان الأساسية للضوء في نظام RGB هي الأحمر والأخضر والأزرق.","The primary colors of light in the RGB system are red, green, and blue."),
    Fact(38,"الفنون","Arts","آلة البيانو","Piano","يُصنف البيانو ضمن الآلات الوترية ذات المفاتيح.","The piano is classified as a keyboard string instrument."),
    Fact(39,"العلوم","Science","الصوت والفراغ","Sound in a vacuum","لا ينتقل الصوت في الفراغ لأنه يحتاج إلى وسط مادي لينتشر.","Sound cannot travel through a vacuum because it needs a material medium."),
    Fact(40,"الفضاء والفلك","Space","القمر","The Moon","القمر هو القمر الطبيعي الوحيد للأرض.","The Moon is Earth's only natural satellite.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        setContent { KnowledgeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KnowledgeApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("knowledge_app", Context.MODE_PRIVATE) }
    var english by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("") }
    val favorites = remember {
        mutableStateListOf<Int>().apply {
            addAll(prefs.getStringSet("favorites", emptySet())?.mapNotNull { it.toIntOrNull() } ?: emptyList())
        }
    }
    var points by remember { mutableIntStateOf(prefs.getInt("points", 0)) }
    var quizIndex by remember { mutableIntStateOf(0) }
    var quizChoice by remember { mutableStateOf(-1) }
    var quizChecked by remember { mutableStateOf(false) }
    var earnedThisAnswer by remember { mutableStateOf(false) }
    val answeredQuestions = remember {
        mutableStateListOf<Int>().apply {
            addAll(prefs.getStringSet("answered_questions", emptySet())?.mapNotNull { it.toIntOrNull() } ?: emptyList())
        }
    }
    val currentQuestion = quizQuestions[quizIndex % quizQuestions.size]
    fun toggleFavorite(id: Int) {
        if (favorites.contains(id)) favorites.remove(id) else favorites.add(id)
        prefs.edit().putStringSet("favorites", favorites.map { it.toString() }.toSet()).apply()
    }
    val navy = Color(0xFF18345B)
    val gold = Color(0xFFC49A4A)
    val categoryPairs = facts.map { it.categoryAr to it.categoryEn }.distinct()
    val filtered = facts.filter { f ->
        val searchable = if (english) "${f.titleEn} ${f.bodyEn} ${f.categoryEn}" else "${f.titleAr} ${f.bodyAr} ${f.categoryAr}"
        val categoryMatches = selectedCategory.isBlank() || f.categoryAr == selectedCategory
        categoryMatches && searchable.contains(query, ignoreCase = true)
    }
    val labels = if (english) listOf("Home", "Search", "Quiz", "Saved") else listOf("الرئيسية", "بحث", "مسابقة", "المفضلة")

    MaterialTheme(colorScheme = lightColorScheme(primary = navy, secondary = gold, background = Color(0xFFF5F7FA))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (english) "Knowledge Encyclopedia" else "موسوعة المعرفة", fontWeight = FontWeight.Bold) },
                    actions = { TextButton(onClick = { english = !english; query = ""; selectedCategory = "" }) { Text(if (english) "العربية" else "EN") } }
                )
            },
            bottomBar = {
                NavigationBar {
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = page == i,
                            onClick = { page = i },
                            icon = { Icon(when (i) { 0 -> Icons.Default.Home; 1 -> Icons.Default.Search; 2 -> Icons.Default.Quiz; else -> Icons.Default.Bookmark }, contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { insets ->
            Column(Modifier.fillMaxSize().padding(insets).padding(horizontal = 16.dp)) {
                when (page) {
                    0 -> {
                        Card(colors = CardDefaults.cardColors(containerColor = navy), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 14.dp)) {
                            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(if (english) "Discover something new every day" else "اكتشف شيئاً جديداً كل يوم", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text(if (english) "Daily knowledge" else "معلومة اليوم", color = Color(0xFFFFD98A))
                                Text(if (english) facts[5].bodyEn else facts[5].bodyAr, color = Color.White)
                            }
                        }
                        Text(if (english) "Explore knowledge" else "اكتشف المعرفة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        CategorySelector(categoryPairs, selectedCategory, english) { selectedCategory = it }
                        LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            items(filtered) { f -> FactCard(f, english, favorites.contains(f.id)) { id -> toggleFavorite(id) } }
                        }
                    }
                    1 -> {
                        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), label = { Text(if (english) "Search facts" else "ابحث في المعلومات") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                        CategorySelector(categoryPairs, selectedCategory, english) { selectedCategory = it }
                        LazyColumn(contentPadding = PaddingValues(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            items(filtered) { f -> FactCard(f, english, favorites.contains(f.id)) { id -> toggleFavorite(id) } }
                        }
                    }
                    2 -> {
                        Column(Modifier.fillMaxWidth().padding(top = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(if (english) "Knowledge Quiz" else "اختبر معلوماتك", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text(if (english) "Your points: $points" else "رصيد نقاطك: $points", color = gold, fontWeight = FontWeight.Bold)
                            Text(if (english) "Question ${quizIndex % quizQuestions.size + 1} of ${quizQuestions.size}" else "السؤال ${quizIndex % quizQuestions.size + 1} من ${quizQuestions.size}", color = gold, fontWeight = FontWeight.Bold)
                            Text(if (english) currentQuestion.questionEn else currentQuestion.questionAr, fontWeight = FontWeight.SemiBold)
                            (if (english) currentQuestion.optionsEn else currentQuestion.optionsAr).forEachIndexed { i, option ->
                                OutlinedButton(onClick = { if (!quizChecked) quizChoice = i }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (quizChecked && i == currentQuestion.answer) Color(0xFFE5F4EA) else Color.Transparent)) { Text(option) }
                            }
                            Button(onClick = {
                                quizChecked = true
                                earnedThisAnswer = quizChoice == currentQuestion.answer && !answeredQuestions.contains(currentQuestion.id)
                                if (earnedThisAnswer) {
                                    points += 10
                                    answeredQuestions.add(currentQuestion.id)
                                    prefs.edit().putInt("points", points).putStringSet("answered_questions", answeredQuestions.map { it.toString() }.toSet()).apply()
                                }
                            }, enabled = quizChoice >= 0 && !quizChecked, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Check answer" else "تأكيد الإجابة") }
                            if (quizChecked) {
                                val correct = quizChoice == currentQuestion.answer
                                Text(if (correct) { if (english) "Correct answer!" else "إجابة صحيحة!" } else { if (english) "Incorrect answer" else "إجابة غير صحيحة" }, color = if (correct) Color(0xFF23834D) else MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                if (correct) Text(if (earnedThisAnswer) { if (english) "+10 points added" else "تمت إضافة 10 نقاط إلى رصيدك" } else { if (english) "Points for this question were already awarded" else "سبق احتساب نقاط هذا السؤال" }, color = gold, fontWeight = FontWeight.SemiBold)
                                Text(if (english) currentQuestion.explanationEn else currentQuestion.explanationAr, style = MaterialTheme.typography.bodyMedium)
                                OutlinedButton(onClick = { quizIndex = (quizIndex + 1) % quizQuestions.size; quizChoice = -1; quizChecked = false; earnedThisAnswer = false }, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Next question" else "السؤال التالي") }
                            }
                        }
                    }
                    else -> {
                        Text(if (english) "Saved facts" else "المعلومات المحفوظة", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 8.dp))
                        val saved = facts.filter { favorites.contains(it.id) }
                        if (saved.isEmpty()) Text(if (english) "No saved facts yet." else "لا توجد معلومات محفوظة بعد.", color = Color.Gray)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            items(saved) { f -> FactCard(f, english, true) { id -> toggleFavorite(id) } }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun CategorySelector(categories: List<Pair<String, String>>, selected: String, english: Boolean, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = selected.isBlank(), onClick = { onSelect("") }, label = { Text(if (english) "All" else "الكل") })
        categories.forEach { pair ->
            FilterChip(selected = selected == pair.first, onClick = { onSelect(pair.first) }, label = { Text(if (english) pair.second else pair.first) })
        }
    }
}

@Composable
private fun FactCard(fact: Fact, english: Boolean, saved: Boolean, onFavorite: (Int) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(if (english) fact.titleEn else fact.titleAr, fontWeight = FontWeight.Bold)
                Text(if (english) fact.bodyEn else fact.bodyAr, style = MaterialTheme.typography.bodyMedium)
                Text(if (english) fact.categoryEn else fact.categoryAr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
            }
            IconButton(onClick = { onFavorite(fact.id) }) { Icon(if (saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, contentDescription = "Favorite") }
        }
    }
}
